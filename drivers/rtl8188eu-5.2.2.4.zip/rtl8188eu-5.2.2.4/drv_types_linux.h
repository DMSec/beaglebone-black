/* SPDX-License-Identifier: GPL-2.0 */
/* Copyright(c) 2007 - 2016 Realtek Corporation. All rights reserved. */

#ifndef __DRV_TYPES_LINUX_H__
#define __DRV_TYPES_LINUX_H__


#endif
