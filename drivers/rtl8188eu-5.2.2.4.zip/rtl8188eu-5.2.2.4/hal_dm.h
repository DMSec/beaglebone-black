/* SPDX-License-Identifier: GPL-2.0 */
/* Copyright(c) 2007 - 2016 Realtek Corporation. All rights reserved. */

#ifndef __HAL_DM_H__
#define __HAL_DM_H__

void Init_ODM_ComInfo(_adapter *adapter);

#endif /* __HAL_DM_H__ */
